import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool, Empty
from visualization_msgs.msg import Marker
from sensor_msgs.msg import LaserScan
from find_object_2d.msg import ObjectsStamped
from geometry_msgs.msg import PointStamped
from tf2_ros import Buffer, TransformListener, TransformException
from tf2_geometry_msgs import do_transform_point
import math


START_MARKER_ID = 13
REQUIRED_HAZARDS = 5
EXPLORE_TIMEOUT_SECONDS = 180.0


class HazardManager(Node):
    def __init__(self):
        super().__init__('hazard_manager')

        self.state = 'idle'
        self.return_triggered = False
        self.started = False
        self.hazards_found = []
        self.latest_scan = None
        self.pending = {}
        self.explore_timeout_timer = None

        # Publishers
        self.status_pub = self.create_publisher(String, '/snc_status', 10)
        self.stop_pub = self.create_publisher(Bool, '/hazard_stop', 10)
        self.home_pub = self.create_publisher(Empty, '/trigger_home', 10)
        self.hazard_pub = self.create_publisher(Marker, '/hazards', 10)
        self.start_pub = self.create_publisher(Empty, '/trigger_start', 10)

        # Subscribers
        self.create_subscription(Empty, '/trigger_start', self.start_callback, 10)
        self.create_subscription(Empty, '/trigger_home', self.home_callback, 10)
        self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.create_subscription(ObjectsStamped, '/objectsStamped', self.detection_callback, 10)

        # TF
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.set_state('idle')
        self.get_logger().info('Hazard manager online')

    def scan_callback(self, msg):
        self.latest_scan = msg

    def set_state(self, new_state: str):
        self.state = new_state
        self.publish_status(new_state)

        if new_state == 'idle':
            self.publish_stop(True)
        elif new_state == 'exploring':
            self.publish_stop(False)
        elif new_state == 'processing_hazard':
            self.publish_stop(True)
        elif new_state == 'returning_home':
            self.publish_stop(False)

        self.get_logger().info(f'State changed to: {new_state}')

    def publish_status(self, text: str):
        msg = String()
        msg.data = text
        self.status_pub.publish(msg)

    def publish_stop(self, active: bool):
        msg = Bool()
        msg.data = active
        self.stop_pub.publish(msg)

    def start_callback(self, msg):
        if self.state == 'idle':
            self.set_state('exploring')
            self.start_explore_timeout()

    def trigger_start(self):
        if self.started:
            return

        self.get_logger().info('Start marker detected, publishing /trigger_start')
        self.start_pub.publish(Empty())
        self.started = True

    def home_callback(self, msg):
        if self.state == 'returning_home':
            return

        self.get_logger().info('/trigger_home received, switching to returning_home')
        self.return_triggered = True
        self.cancel_explore_timeout()
        self.set_state('returning_home')

    def trigger_return_home(self):
        if self.return_triggered:
            return

        self.get_logger().info('Publishing /trigger_home')
        self.return_triggered = True
        self.cancel_explore_timeout()
        self.set_state('returning_home')
        self.home_pub.publish(Empty())

    def start_explore_timeout(self):
        if self.explore_timeout_timer is not None:
            return

        self.get_logger().info(
            f'Explore timeout started: return home in {EXPLORE_TIMEOUT_SECONDS:.0f}s if fewer than {REQUIRED_HAZARDS} hazards found'
        )
        self.explore_timeout_timer = self.create_timer(
            EXPLORE_TIMEOUT_SECONDS,
            self.explore_timeout_callback
        )

    def cancel_explore_timeout(self):
        if self.explore_timeout_timer is not None:
            self.explore_timeout_timer.cancel()
            self.explore_timeout_timer = None

    def explore_timeout_callback(self):
        self.cancel_explore_timeout()

        if self.state != 'exploring':
            return

        if len(self.hazards_found) < REQUIRED_HAZARDS:
            self.get_logger().info(
                f'Explore timeout reached with {len(self.hazards_found)}/{REQUIRED_HAZARDS} hazards found -> triggering return home'
            )
            self.trigger_return_home()

    def detection_callback(self, msg):
        data = msg.objects.data
        if len(data) < 12:
            return

        for i in range(0, len(data), 12):
            if i + 11 >= len(data):
                break

            parsed = self.parse_detection(data, i)
            if parsed is None:
                continue

            hazard_id, u, v = parsed

            if hazard_id == START_MARKER_ID:
                self.trigger_start()
                continue

            if self.latest_scan is None:
                continue

            if self.state not in ('exploring', 'returning_home'):
                continue

            self.handle_detection(hazard_id, u, v)

    def parse_detection(self, data, i):
        hazard_id = int(data[i])
        obj_w = data[i + 1]
        obj_h = data[i + 2]

        h11 = data[i + 3]
        h12 = data[i + 4]
        h13 = data[i + 5]
        h21 = data[i + 6]
        h22 = data[i + 7]
        h23 = data[i + 8]
        h31 = data[i + 9]
        h32 = data[i + 10]
        h33 = data[i + 11]

        cx = obj_w / 2.0
        cy = obj_h / 2.0

        denom = h13 * cx + h23 * cy + h33
        if abs(denom) < 1e-6:
            return None

        u = (h11 * cx + h21 * cy + h31) / denom
        v = (h12 * cx + h22 * cy + h32) / denom

        return hazard_id, u, v

    def handle_detection(self, hazard_id, u, v):
        if not self.is_stable_detection(hazard_id, u):
            return

        theta = self.pixel_to_angle(u)
        distance = self.get_range_at_angle(self.latest_scan, theta)

        if distance is None:
            self.get_logger().info(f'Hazard {hazard_id}: no valid laser range')
            return

        x_robot = distance * math.cos(theta)
        y_robot = distance * math.sin(theta)

        result = self.transform_to_map(x_robot, y_robot)
        if result is None:
            return

        x_map, y_map = result

        self.get_logger().info(
            f'Hazard {hazard_id}: u={u:.1f}, theta={math.degrees(theta):.1f} deg, '
            f'd={distance:.2f}, map=({x_map:.2f}, {y_map:.2f}), state={self.state}'
        )

        self.process_hazard(hazard_id, x_map, y_map)

        self.pending[hazard_id] = {'count': 0, 'u': u}

    def is_stable_detection(self, hazard_id, u, required_count=3, max_pixel_jump=20.0):
        if hazard_id not in self.pending:
            self.pending[hazard_id] = {'count': 1, 'u': u}
            return False

        if abs(self.pending[hazard_id]['u'] - u) < max_pixel_jump:
            self.pending[hazard_id]['count'] += 1
            self.pending[hazard_id]['u'] = u
        else:
            self.pending[hazard_id] = {'count': 1, 'u': u}
            return False

        return self.pending[hazard_id]['count'] >= required_count

    def pixel_to_angle(self, u, image_width=640.0, hfov_deg=60.0):
        cx = image_width / 2.0
        hfov_rad = math.radians(hfov_deg)

        return ((cx - u) / cx) * (hfov_rad / 2.0)

    def get_range_at_angle(self, scan, theta, window=4):
        center = int((theta - scan.angle_min) / scan.angle_increment)
        values = []

        for index in range(center - window, center + window + 1):
            if 0 <= index < len(scan.ranges):
                r = scan.ranges[index]
                if not math.isinf(r) and not math.isnan(r):
                    if scan.range_min <= r <= scan.range_max:
                        values.append(r)

        if not values:
            return None

        return min(values)

    def transform_to_map(self, x_robot, y_robot):
        point = PointStamped()
        point.header.frame_id = 'base_link'
        point.header.stamp = self.get_clock().now().to_msg()
        point.point.x = x_robot
        point.point.y = y_robot
        point.point.z = 0.0

        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                'base_link',
                rclpy.time.Time()
            )
            map_point = do_transform_point(point, transform)
            return map_point.point.x, map_point.point.y
        except TransformException as e:
            self.get_logger().warn(f'TF failed: {e}')
            return None

    def process_hazard(self, hazard_id, x, y):
        if self.state not in ('exploring', 'returning_home'):
            return

        if self.is_duplicate(hazard_id, x, y):
            return

        old_state = self.state

        if old_state == 'exploring':
            self.set_state('processing_hazard')

        self.hazards_found.append((hazard_id, x, y))
        self.publish_hazard(hazard_id, x, y)

        if len(self.hazards_found) >= 5 and not self.return_triggered:
            self.get_logger().info("5 hazards found -> triggering return home")
            self.trigger_return_home()
            return

        if old_state == 'exploring':
            self.set_state('exploring')
        else:
            self.set_state('returning_home')

    def is_duplicate(self, hazard_id, x, y, threshold=1.0):
        for old_id, old_x, old_y in self.hazards_found:
            if old_id == hazard_id:
                return True
        return False

    def publish_hazard(self, hazard_id, x, y):
        marker = Marker()
        marker.header.frame_id = 'map'
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'hazards'

        marker.id = hazard_id

        marker.type = Marker.SPHERE
        marker.action = Marker.ADD

        marker.pose.position.x = x
        marker.pose.position.y = y
        marker.pose.position.z = 0.0
        marker.pose.orientation.w = 1.0

        marker.scale.x = 0.2
        marker.scale.y = 0.2
        marker.scale.z = 0.2

        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0

        self.hazard_pub.publish(marker)


def main(args=None):
    rclpy.init(args=args)
    node = HazardManager()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
