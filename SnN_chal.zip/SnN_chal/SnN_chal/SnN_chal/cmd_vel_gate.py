import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from std_msgs.msg import Bool


class CmdVelGate(Node):
    def __init__(self):
        super().__init__('cmd_vel_gate')

        self.stop_active = False

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.stop_sub = self.create_subscription(
            Bool,
            '/hazard_stop',
            self.stop_callback,
            10
        )

        self.nav_sub = self.create_subscription(
            Twist,
            '/cmd_vel_nav',
            self.nav_callback,
            10
        )

        self.teleop_sub = self.create_subscription(
            Twist,
            '/cmd_vel_teleop',
            self.teleop_callback,
            10
        )

        self.get_logger().info('cmd_vel_gate node started')

    def stop_callback(self, msg):
        self.stop_active = msg.data
        if self.stop_active:
            self.cmd_pub.publish(Twist())
            self.get_logger().info('Stop active, publishing zero velocity')

    def nav_callback(self, msg):
        if not self.stop_active:
            self.cmd_pub.publish(msg)

    def teleop_callback(self, msg):
        if not self.stop_active:
            self.cmd_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = CmdVelGate()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()