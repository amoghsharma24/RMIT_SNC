import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool, Empty
from visualization_msgs.msg import Marker
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import PointStamped
from tf2_ros import Buffer, TransformListener, TransformException
from tf2_geometry_msgs import do_transform_point
import math

class HazardManager(Node):
    def __init__(self):
        super().__init__('hazard_manager')

        self.state = 'idle'
        self.hazards_found = []
        self.latest_scan = None
        self.pending = {}

        # Publishers
        self.status_pub = self.create_publisher(String, '/snc_status', 10)
        self.stop_pub = self.create_publisher(Bool, '/hazard_stop', 10)
        self.home_pub = self.create_publisher(Empty, '/trigger_home', 10)
        self.hazard_pub = self.create_publisher(Marker, '/hazards', 10)

        # Subscribers
        self.create_subscription(Empty, '/trigger_start', self.start_callback, 10)
        self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.create_subscription(Float32MultiArray, '/objectsStamped', self.detection_callback, 10)

        # TF
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.set_state('idle')

    def scan_callback(self, msg):
        self.latest_scan = msg

    def set_state(self, new_state: str):
        self.state = new_state
        self.publish_status(new_state)

        if new_state == 'idle':
            self.publish_stop(True)
        elif new_state == 'exploring':
            self.publish_stop(False)
        elif new_state == 'processing_hazard':
            self.publish_stop(True)
        elif new_state == 'returning_home':
            self.publish_stop(False)

    def publish_status(self, text: str):
        msg = String()
        msg.data = text
        self.status_pub.publish(msg)

    def publish_stop(self, active: bool):
        msg = Bool()
        msg.data = active
        self.stop_pub.publish(msg)

    def start_callback(self, msg):
        if self.state == 'idle':
            self.set_state('exploring')

    def detection_callback(self, msg):
        if self.latest_scan is None or self.state != 'exploring':
            return

        data = msg.data
        if len(data) < 12:
            return

        for i in range(0, len(data), 12):
            hazard_id = int(data[i])
            u = data[i + 9]
            v = data[i + 10]
            self.handle_detection(hazard_id, u, v)

    def handle_detection(self, hazard_id, u, v):
        # Stability check
        key = hazard_id
        if key not in self.pending:
            self.pending[key] = {'count': 0, 'u': u}

        if abs(self.pending[key]['u'] - u) < 20.0:
            self.pending[key]['count'] += 1
            self.pending[key]['u'] = u
        else:
            self.pending[key] = {'count': 1, 'u': u}

        if self.pending[key]['count'] < 3:
            return

        theta = self.pixel_to_angle(u)
        distance = self.get_range_at_angle(self.latest_scan, theta)

        if distance is None:
            return

        x_robot = distance * math.cos(theta)
        y_robot = distance * math.sin(theta)

        result = self.transform_to_map(x_robot, y_robot)
        if result is None:
            return

        x_map, y_map = result

        self.get_logger().info(
            f'Hazard {hazard_id}: u={u:.1f}, theta={math.degrees(theta):.1f} deg, '
            f'd={distance:.2f}, map=({x_map:.2f}, {y_map:.2f})'
        )

        self.process_hazard(hazard_id, x_map, y_map)

    def pixel_to_angle(self, u, image_width=640.0, hfov_deg=60.0):
        cx = image_width / 2.0
        hfov_rad = math.radians(hfov_deg)
        return ((u - cx) / cx) * (hfov_rad / 2.0)

    def get_range_at_angle(self, scan, theta, window=2):
        center = int((theta - scan.angle_min) / scan.angle_increment)
        values = []

        for i in range(center - window, center + window + 1):
            if 0 <= i < len(scan.ranges):
                r = scan.ranges[i]
                if not math.isinf(r) and not math.isnan(r):
                    if scan.range_min <= r <= scan.range_max:
                        values.append(r)

        if not values:
            return None

        return min(values)

    def transform_to_map(self, x_robot, y_robot):
        point = PointStamped()
        point.header.frame_id = 'base_link'
        point.header.stamp = self.get_clock().now().to_msg()
        point.point.x = x_robot
        point.point.y = y_robot
        point.point.z = 0.0

        try:
            transform = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            map_point = do_transform_point(point, transform)
            return map_point.point.x, map_point.point.y
        except TransformException as e:
            self.get_logger().warn(f'TF failed: {e}')
            return None

    def process_hazard(self, hazard_id, x, y):
        if not self.is_duplicate(hazard_id, x, y):
            self.hazards_found.append((hazard_id, x, y))
            self.publish_hazard(hazard_id, x, y)

        if len(self.hazards_found) >= 5:
            self.set_state('returning_home')
            self.home_pub.publish(Empty())

    def is_duplicate(self, hazard_id, x, y, threshold=0.5):
        for old_id, old_x, old_y in self.hazards_found:
            if old_id == hazard_id:
                dx = x - old_x
                dy = y - old_y
                if math.sqrt(dx*dx + dy*dy) < threshold:
                    return True
        return False

    def publish_hazard(self, hazard_id, x, y):
        marker = Marker()
        marker.header.frame_id = 'map'
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'hazards'
        marker.id = len(self.hazards_found)
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD

        marker.pose.position.x = x
        marker.pose.position.y = y
        marker.pose.position.z = 0.0
        marker.pose.orientation.w = 1.0

        marker.scale.x = 0.2
        marker.scale.y = 0.2
        marker.scale.z = 0.2

        marker.color.a = 1.0
        marker.color.r = 1.0

        self.hazard_pub.publish(marker)


def main(args=None):
    rclpy.init(args=args)
    node = HazardManager()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
