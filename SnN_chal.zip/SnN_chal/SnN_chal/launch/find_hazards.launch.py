from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([

        Node(
            package='find_object_2d',
            executable='find_object_2d',
            name='find_object_2d',
            output='screen',
            parameters=[{
                'gui': True,
                'subscribe_depth': False,
                'objects_path': '~/aiil_workspace/humble_workspace/src/SnN_chal/objects',
                'settings_path': '~/.ros/find_object_2d.ini',

                'feature_type': 6,
                'max_features': 200,
                'min_inliers': 8,
                'max_neighbors': 2,
                'threads': 1,
            }],
            remappings=[
                ('image', '/camera/color/image_raw'),
            ]
        )

    ])