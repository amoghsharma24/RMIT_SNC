from setuptools import find_packages, setup

package_name = 'SnN_chal'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/find_hazards.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rmitaiil',
    maintainer_email='s4037298@student.rmit.edu.au',
    description='Path tracker and hazard manager',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'hazard_manager = SnN_chal.hazard_manager:main',
            'cmd_vel_gate = SnN_chal.cmd_vel_gate:main',
        ],
    },
    extras_require={
        'test': [
            'pytest',
        ],
    },
)
