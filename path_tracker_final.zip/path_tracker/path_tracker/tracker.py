import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from tf2_ros import TransformException
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty

class PathTrackerNode(Node):
    def __init__(self):
        super().__init__('path_tracker_node')

        # 1. TF Setup (Position Tracking)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # 2. Path Publishing Setup
        self.path_pub = self.create_publisher(Path, '/path_explore', 10)
        self.robot_path = Path()
        self.robot_path.header.frame_id = 'map'

        # 3. Navigation Client (Return Home)
        self._nav_client = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        # 4. Trigger Listener
        self.trigger_sub = self.create_subscription(Empty, '/trigger_home', self.home_callback, 10)

        # 5. Timer (Update every 1 second)
        self.timer = self.create_timer(1.0, self.track_and_publish)
        
        self.get_logger().info('NODE 3 ONLINE: Tracking enabled. Waiting for /trigger_home...')

    def track_and_publish(self):
        try:
            now = rclpy.time.Time()
            t = self.tf_buffer.lookup_transform('map', 'base_link', now)
            
            # Create a point for the path
            pose = PoseStamped()
            pose.header.stamp = self.get_clock().now().to_msg()
            pose.header.frame_id = 'map'
            pose.pose.position.x = t.transform.translation.x
            pose.pose.position.y = t.transform.translation.y
            
            # Add to path list and publish
            self.robot_path.poses.append(pose)
            self.robot_path.header.stamp = self.get_clock().now().to_msg()
            self.path_pub.publish(self.robot_path)
            
            self.get_logger().info(f'Tracking: X={pose.pose.position.x:.2f}, Y={pose.pose.position.y:.2f}')
        except TransformException:
            pass

    def home_callback(self, msg):
        self.get_logger().warn('!!! RETURN TO HOME SIGNAL RECEIVED !!!')
        self.go_to_origin()

    def go_to_origin(self):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.pose.position.x = 0.0
        goal_msg.pose.pose.position.y = 0.0
        goal_msg.pose.pose.orientation.w = 1.0

        self._nav_client.wait_for_server()
        self._nav_client.send_goal_async(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PathTrackerNode()
    rclpy.spin(node)
    rclpy.shutdown()